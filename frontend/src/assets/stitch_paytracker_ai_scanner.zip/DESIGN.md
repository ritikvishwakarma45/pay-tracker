---
name: PayTracker Logic
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#46474a'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#76777b'
  outline-variant: '#c6c6ca'
  surface-tint: '#5e5e62'
  primary: '#090a0d'
  on-primary: '#ffffff'
  primary-container: '#202124'
  on-primary-container: '#88888c'
  inverse-primary: '#c7c6ca'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#090b0c'
  on-tertiary: '#ffffff'
  tertiary-container: '#1f2223'
  on-tertiary-container: '#87898a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3e2e6'
  primary-fixed-dim: '#c7c6ca'
  on-primary-fixed: '#1a1b1e'
  on-primary-fixed-variant: '#46474a'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#e1e3e4'
  tertiary-fixed-dim: '#c5c7c8'
  on-tertiary-fixed: '#191c1d'
  on-tertiary-fixed-variant: '#454748'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style

The design system is rooted in **Modern Minimalism**, tailored specifically for high-fidelity fintech applications. It prioritizes clarity, speed of comprehension, and a sense of absolute financial control. The aesthetic is "SaaS-inspired," utilizing a reduced visual noise approach to highlight critical data points and AI-driven insights.

The target audience consists of professionals and tech-savvy users who require a high-utility environment that feels both sophisticated and approachable. By leveraging ample whitespace and a restrained color palette, the UI evokes feelings of transparency, precision, and institutional reliability.

## Colors

The color strategy is functional rather than decorative. 
- **Primary (#202124):** Used for maximum legibility in typography and primary navigation elements.
- **Secondary (#10B981):** A vibrant Emerald Green reserved for growth indicators, success states, and primary Call-to-Action (CTA) buttons. It symbolizes financial health.
- **Surface (#F8F9FA):** A soft light gray used to differentiate cards, background sections, and input fields from the pure white base.
- **Foundation (#FFFFFF):** The global background color, providing the clean canvas necessary for a minimalist layout.

## Typography

This design system utilizes **Inter** exclusively to maintain a systematic and utilitarian feel. The scale emphasizes a tight vertical rhythm. 

- **Headlines:** Use tighter letter spacing and heavier weights to create a strong visual anchor.
- **Body:** Optimized for readability with a generous line height (1.5x) to ensure large amounts of financial data remain digestible.
- **Labels:** Used for metadata, table headers, and overlines, often employing medium or semi-bold weights to distinguish them from body text without increasing size.

## Layout & Spacing

The layout follows a **12-column fluid grid** for desktop and a **4-column grid** for mobile. 

- **Rhythm:** An 8px linear scale (with a 4px step for tight components) governs all padding and margins.
- **Margins:** Desktop views should maintain 24px-48px outer margins, while mobile stays strictly at 16px to maximize horizontal space for data tables.
- **Alignment:** All content blocks must align to the top-left of their respective grid containers to maintain a structured, professional appearance.

## Elevation & Depth

To maintain a minimalist aesthetic, depth is achieved through **Tonal Layers** and **Subtle Shadows**. 

- **Level 0 (Base):** Pure White (#FFFFFF) for the main canvas.
- **Level 1 (Cards):** Light Gray (#F8F9FA) backgrounds with no shadows, or White backgrounds with a 1px border (#E5E7EB).
- **Level 2 (Active Elements):** White surfaces with a soft, diffused shadow: `0px 4px 12px rgba(0, 0, 0, 0.05)`. This is used for dropdowns, hover states on cards, and modals.
- **Focus States:** A 2px Emerald Green (#10B981) ring with an offset of 2px is used for keyboard navigation and active input fields.

## Shapes

The design system employs a consistent **12px (0.75rem)** corner radius for all primary UI components like cards, buttons, and input fields. This "Rounded" approach softens the professional tone, making the fintech experience feel modern and accessible rather than overly rigid.

- **Small elements (Tags/Chips):** Use 6px or full pill shapes.
- **Large elements (Modals/Sections):** Use the standard 12px or 16px (rounded-lg) for a more pronounced enclosure.

## Components

- **Buttons:** Primary buttons use a solid Emerald Green background with white text. Secondary buttons use the Charcoal text with a light gray background or a simple 1px outline. Use 12px rounding.
- **Input Fields:** 12px rounded corners, #F8F9FA background, and a subtle 1px border that turns Emerald Green on focus. Labels should be positioned above the field using the `label-md` style.
- **Cards:** Use either a #F8F9FA background or a white background with a very soft shadow. Ensure internal padding is at least 24px (lg).
- **Chips/Status:** For "Growth" or "Success," use a light green tint (#D1FAE5) with Emerald Green text. For neutral states, use light gray.
- **Icons:** Use 24px minimal outline icons with a 1.5px or 2px stroke width. Icons should match the text color (#202124) unless they are destructive (Red) or positive (Green).
- **AI Insights:** Use a subtle gradient border or a specific "AI" badge in a muted purple or blue to distinguish automated insights from manual data entry.